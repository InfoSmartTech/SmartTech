package Loop;

public class ForLoop {
	
	public static void main(String[] args){
		
		int number = 100;
		
		for(int i = 0; i<number; i++) {
			
			if(i==50) {
				
				//continue;
				break;
				
			}else {
				System.out.println(i);
				System.out.println(i);
			}
			
		}		
		
	}

}
